package com.sist.test;

public class Test10 {
	public static void main(String[] args) {
		for(int i =10; i<100;i++ ) {
			if(i%10 == i/10) {
				System.out.print(i + "  ");
			}
		}
	}
}
